package com.bezkoder.spring.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbctemplateCrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJdbctemplateCrudExampleApplication.class, args);
	}

}
