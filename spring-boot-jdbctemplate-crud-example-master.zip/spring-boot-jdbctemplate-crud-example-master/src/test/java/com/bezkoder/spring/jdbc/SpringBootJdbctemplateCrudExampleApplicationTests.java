package com.bezkoder.spring.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJdbctemplateCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
